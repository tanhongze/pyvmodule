loongson_copyright=['''//+FHDR-----------------------------------------------------------------
// (C) Copyright Loongson Technology Corporation Limited. All rights reserved
// Loongson Confidential Proprietary
//-FHDR-----------------------------------------------------------------''']
